package com.example.demo;

import java.util.Base64;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

public class Demo {

    private static Map<Object, String> secrets = new HashMap<>();

    public static void main(String[] args) {

        String key = "my-custom-key";
        String value = "My secret no one should know!";
        String inputKey = "mY-cUsTom-kEy";

        storeSecret(key, value, false);
        retriveSecret(inputKey);

    }

    private static Optional<String> retriveSecret(String inputKey) {

        if(inputKey == null || inputKey.isEmpty()) {
            return Optional.empty();
        }
        return Optional.ofNullable(secrets.get(inputKey.toLowerCase()));
    }

    private static Object storeSecret(Object secretKey, String secretValue, boolean enc) {

        if(secretKey instanceof Integer){
            secrets.put(secretKey, secretValue);
            return secretKey;
        } else if(secretKey instanceof String) {
            String newKey = secretKey.toString();
            if (secretKey != null || !newKey.isEmpty() || newKey.length() <= 20) {
                if(secretValue.equals(secrets.get(newKey.toLowerCase()))) {
                    throw new IllegalArgumentException("Changing secret value not supported.");
                }

                if(enc) {
                    String encVal = Base64.getEncoder().encodeToString(secrets.get(newKey.toLowerCase()).getBytes());
                    Optional.ofNullable(encVal.substring(0, 6));
                }
                secrets.put(newKey.toLowerCase(), secretValue);
                return newKey.toLowerCase();
            } else {
                throw new IllegalArgumentException("Invalid secret key supplied.");
            }
        }
        return null;
    }
}
